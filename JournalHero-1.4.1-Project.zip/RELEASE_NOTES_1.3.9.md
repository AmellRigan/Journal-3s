# Journal Hero 1.3.9 — persistent habits and contracts

## Added
- User-created habits are now stored locally and survive app restarts.
- Positive and negative habit marks are saved with a per-action history.
- Habit cards show the actual positive/negative totals and a simple positive ratio.
- User-created long-term contracts are stored locally.
- Contracts support up to 50 milestones entered on separate lines.
- Milestone completion is persisted and contract progress is recalculated from completed milestones.
- Saved habits and contracts can be deleted with confirmation.
- New data uses `journalHero.habits.v15` and `journalHero.contracts.v15`; JSON backup automatically includes these `journalHero.*` keys.

## Notes
- Existing example habit and contract cards remain as visual examples; newly created entries are stored separately and rendered below them.
- Data remains on-device. No account or network connection is required.
