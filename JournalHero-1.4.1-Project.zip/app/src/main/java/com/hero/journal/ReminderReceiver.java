package com.hero.journal;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONException;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "journal_hero_reminders";
    static final String PREFS = "journal_hero_reminders";
    static final String EXTRA_ID = "reminder_id";
    static final String EXTRA_TITLE = "reminder_title";
    static final String EXTRA_TIME = "reminder_time";

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            restoreAll(context);
            return;
        }
        if (!"com.hero.journal.SHOW_REMINDER".equals(action)) return;
        String id = intent.getStringExtra(EXTRA_ID);
        String title = intent.getStringExtra(EXTRA_TITLE);
        if (id == null || title == null) return;
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        createChannel(context);
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        Notification notification = builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Журнал Героя")
                .setContentText(title)
                .setStyle(new Notification.BigTextStyle().bigText(title))
                .setContentIntent(content).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER)
                .setPriority(Notification.PRIORITY_DEFAULT).build();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(id.hashCode(), notification);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().remove(id).apply();
    }

    static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, "Напоминания Journal Hero", NotificationManager.IMPORTANCE_DEFAULT));
        }
    }

    static void schedule(Context context, String id, String title, long atMillis) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        Intent intent = new Intent(context, ReminderReceiver.class).setAction("com.hero.journal.SHOW_REMINDER");
        intent.putExtra(EXTRA_ID, id); intent.putExtra(EXTRA_TITLE, title);
        PendingIntent pi = PendingIntent.getBroadcast(context, id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        else alarm.set(AlarmManager.RTC_WAKEUP, atMillis, pi);
        try {
            JSONObject value = new JSONObject(); value.put("id", id); value.put("title", title); value.put("at", atMillis);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(id, value.toString()).apply();
        } catch (JSONException ignored) { }
    }

    static void cancel(Context context, String id) {
        Intent intent = new Intent(context, ReminderReceiver.class).setAction("com.hero.journal.SHOW_REMINDER");
        PendingIntent pi = PendingIntent.getBroadcast(context, id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.cancel(pi);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(id).apply();
    }

    static void restoreAll(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (String key : prefs.getAll().keySet()) {
            try {
                JSONObject item = new JSONObject(prefs.getString(key, "{}"));
                long at = item.optLong("at", 0);
                if (at > System.currentTimeMillis()) schedule(context, item.optString("id", key), item.optString("title", "Напоминание"), at);
                else prefs.edit().remove(key).apply();
            } catch (Exception e) { prefs.edit().remove(key).apply(); }
        }
    }
}
