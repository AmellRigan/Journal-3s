package com.hero.journal;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.pm.PackageManager;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CREATE_BACKUP = 4101;
    private static final int REQUEST_OPEN_BACKUP = 4102;
    private static final int REQUEST_POST_NOTIFICATIONS = 4103;
    private String pendingReminderId;
    private String pendingReminderTitle;
    private long pendingReminderTime;
    private WebView webView;
    private String pendingBackupJson;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Dark status and navigation bars
        getWindow().setStatusBarColor(Color.parseColor("#07030a"));
        getWindow().setNavigationBarColor(Color.parseColor("#07030a"));

        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);

        configureWebView();

        // JS bridge: JavaScript can call Android.toast("text")
        webView.addJavascriptInterface(new JsBridge(this), "Android");
        ReminderReceiver.createChannel(this);

        // Handle back button via modern API (avoids deprecation on API 33+)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        // Load the app — served from assets/web/index.html
        webView.loadUrl("file:///android_asset/web/index.html");
    }

    private void chooseBackupDestination(String json) {
        pendingBackupJson = json;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "JournalHero-backup-" +
                new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date()) + ".json");
        startActivityForResult(intent, REQUEST_CREATE_BACKUP);
    }

    private void chooseBackupFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain"});
        startActivityForResult(intent, REQUEST_OPEN_BACKUP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            pendingBackupJson = null;
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQUEST_CREATE_BACKUP) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null || pendingBackupJson == null) throw new java.io.IOException("Не удалось открыть файл для записи");
                out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                out.flush();
                Toast.makeText(this, "Резервная копия сохранена", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Ошибка сохранения копии: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                pendingBackupJson = null;
            }
        } else if (requestCode == REQUEST_OPEN_BACKUP) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                if (in == null) throw new java.io.IOException("Не удалось открыть файл");
                byte[] buffer = new byte[8192];
                int count;
                int total = 0;
                while ((count = in.read(buffer)) != -1) {
                    total += count;
                    if (total > 10 * 1024 * 1024) throw new java.io.IOException("Файл превышает 10 МБ");
                    out.write(buffer, 0, count);
                }
                final String json = new String(out.toByteArray(), StandardCharsets.UTF_8);
                if (webView != null) {
                    webView.post(() -> webView.evaluateJavascript(
                            "applyBackupText(" + org.json.JSONObject.quote(json) + ")", null));
                }
            } catch (Exception e) {
                Toast.makeText(this, "Ошибка чтения копии: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingReminderId != null) {
                    ReminderReceiver.schedule(this, pendingReminderId, pendingReminderTitle, pendingReminderTime);
                    Toast.makeText(this, "Напоминание запланировано", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Разрешите уведомления в настройках Android, чтобы получать напоминания", Toast.LENGTH_LONG).show();
            }
            pendingReminderId = null; pendingReminderTitle = null; pendingReminderTime = 0;
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);        // localStorage support
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setMediaPlaybackRequiresUserGesture(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setBackgroundColor(Color.parseColor("#07030a"));

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep all navigation inside WebView
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient());
    }

    // ── JavaScript ↔ Android bridge ──────────────────────────────────────────

    public static final class JsBridge {
        private final MainActivity activity;
        private final Context context;

        JsBridge(MainActivity activity) {
            this.activity = activity;
            this.context = activity;
        }

        @JavascriptInterface
        public void saveBackup(final String json) {
            if (json == null || json.length() > 10 * 1024 * 1024) {
                Toast.makeText(context, "Резервная копия слишком большая", Toast.LENGTH_LONG).show();
                return;
            }
            activity.runOnUiThread(() -> activity.chooseBackupDestination(json));
        }

        @JavascriptInterface
        public void openBackup() {
            activity.runOnUiThread(activity::chooseBackupFile);
        }

        @JavascriptInterface
        public boolean scheduleReminder(final String id, final String title, final long atMillis) {
            if (id == null || id.trim().isEmpty() || title == null || atMillis <= System.currentTimeMillis()) return false;
            activity.runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    activity.pendingReminderId = id; activity.pendingReminderTitle = title; activity.pendingReminderTime = atMillis;
                    activity.requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQUEST_POST_NOTIFICATIONS);
                } else {
                    ReminderReceiver.schedule(activity, id, title, atMillis);
                    Toast.makeText(context, "Напоминание запланировано", Toast.LENGTH_SHORT).show();
                }
            });
            return true;
        }

        @JavascriptInterface
        public void cancelReminder(final String id) {
            if (id != null) activity.runOnUiThread(() -> ReminderReceiver.cancel(activity, id));
        }

        @JavascriptInterface
        public boolean supportsNativeReminders() { return true; }

        @JavascriptInterface
        public void toast(final String message) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }

        @JavascriptInterface
        public int getSdkVersion() {
            return Build.VERSION.SDK_INT;
        }

        @JavascriptInterface
        public String getAppVersion() {
            return BuildConfig.VERSION_NAME;
        }
    }

    // ── Activity lifecycle ────────────────────────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.pauseTimers();
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
